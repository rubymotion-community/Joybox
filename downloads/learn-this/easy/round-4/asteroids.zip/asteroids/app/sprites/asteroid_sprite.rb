class AsteroidSprite < Joybox::Core::Sprite
  def initialize
    
  end
end