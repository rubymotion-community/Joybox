class GameLayer < Joybox::Core::Layer

  def on_enter
    #test_sprite = Sprite.new file_name: 'sprites/game/asteroid-large.png', position: Screen.center
    #self << test_sprite
    SpriteFrameCache.frames.add file_name: 'sprite_sheets/game_sprite_sheet.plist'

    @sprite_batch = SpriteBatch.new file_name: "sprite_sheets/game_sprite_sheet.png"

    test_sprite = Sprite.new frame_name: 'asteroid-large.png', position: Screen.center
    @sprite_batch << test_sprite

    self << @sprite_batch
  end

end