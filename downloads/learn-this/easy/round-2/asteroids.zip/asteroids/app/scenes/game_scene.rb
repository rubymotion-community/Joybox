class GameScene < Joybox::Core::Scene

  def on_enter
  end

end